import json
from base64 import b64decode, b64encode
import numpy as np

def lambda_handler(event, context):
    # TODO implement
    data_numpy = np.frombuffer(b64decode(json.loads(event['data'])), dtype=np.uint8)
    checkbyte = b64encode(data_numpy[0])
    image = b64encode(data_numpy[1:7501])
    return {
        'statusCode': 200,
        'checkbyte':checkbyte,
        'image': image
    }